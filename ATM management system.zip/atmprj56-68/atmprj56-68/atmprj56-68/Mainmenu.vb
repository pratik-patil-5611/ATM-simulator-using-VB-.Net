﻿Public Class Mainmenu
    Dim cmd As New OleDb.OleDbCommand
    Dim da As New OleDb.OleDbDataAdapter
    Dim ds As New DataSet
    Dim con As New OleDb.OleDbConnection
    Dim sql As String
    Private Sub Mainmenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lbldate.Text = Date.Now

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim sql As String
        Dim Log_in As New DataTable
        Try
            con.ConnectionString = ("Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=C:\Users\computer\Pictures\ATMSystem.accdb")
            sql = "SELECT * FROM tblinfo where account_no = " & lblaccno.Text & ""
            With cmd
                .Connection = con
                .CommandText = sql
            End With
            da.SelectCommand = cmd
            da.Fill(Log_in)
            If Log_in.Rows.Count > 0 Then
                Dim balaance As String
                balance = Log_in.Rows(0).Item("Balance")
                Receipt.Show()
                Receipt.lblname.Text = lblname.Text
                Receipt.lblbal.Text = Balance
                Receipt.Label4.Hide()
                Receipt.Label3.Hide()
                Receipt.lbldep.Hide()
                Receipt.lblwith.Hide()
                Receipt.Label6.Hide()
                Receipt.lblnewbal.Hide()
                Me.Hide()
            Else
                MsgBox("Pincode is incorrect")
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class