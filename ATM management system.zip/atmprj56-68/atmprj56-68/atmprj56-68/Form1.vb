﻿Public Class Form1
    Dim cmd As New OleDb.OleDbCommand
    Dim da As New OleDb.OleDbDataAdapter
    Dim ds As New DataSet
    Dim con As New OleDb.OleDbConnection
    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        Dim sql As String
        Dim Log_in As New DataTable
        Try
            If txtpin.Text = "" Then
                MsgBox("Plz Enter in the field")
            Else
                con.ConnectionString = ("Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=C:\Users\computer\Pictures\ATMSystem.accdb")
                sql = "SELECT * FROM tblinfo where pin_code = " & txtpin.Text & ""

                With cmd
                    .Connection = con
                    .CommandText = sql
                End With
                da.SelectCommand = cmd
                da.Fill(Log_in)
                If Log_in.Rows.Count > 0 Then
                    Dim Type, Fullname, accno As String
                    Type = Log_in.Rows(0).Item("type")
                    Fullname = Log_in.Rows(0).Item("Firstname")
                    accno = Log_in.Rows(0).Item("account_no")
                    If Type = "admin" Then
                        MsgBox("Welcome " & Fullname & "You logged in as administrator")
                        AdminForm.Show()
                        Me.Hide()
                    ElseIf Type = "Block" Then
                        MsgBox("Your Account is Currently Blocked")
                        MsgBox("Contact the Administrator for Help")
                    Else
                        MsgBox("Welcome " & Fullname)
                        Mainmenu.lblname.Text = Fullname
                        Mainmenu.lblaccno.Text = accno
                        Me.Hide()
                    End If
                Else
                    MsgBox("You are not registered!!!")
                    MsgBox("Plz Register if you are new")

                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        txtpin.Text = ""

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub txtpin_TextChanged(sender As Object, e As EventArgs) Handles txtpin.TextChanged

    End Sub

    Private Sub llbreg_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbreg.LinkClicked

    End Sub
End Class
