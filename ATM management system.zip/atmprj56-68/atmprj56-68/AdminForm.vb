﻿Public Class AdminForm
    Dim con As New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\comp6\Documents\atmsys.accdb")
    Dim dt As New DataTable
    Dim sql As String
    Dim myds As New DataSet
    Dim da As New OleDb.OleDbDataAdapter
    Dim cmd As New OleDb.OleDbCommand
    Private Sub AdminForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Label11.Text = Date.Now
        
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        sql = "SELECT * FROM tblinfo where Firstname='" & txtfname.Text & "'" & "and Lastname='" & txtlname.Text & "'"
        Try
            con.Open()
            da = New OleDb.OleDbDataAdapter(sql, con)
            da.Fill(dt)
            DataGridView1.DataSource = dt

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information)
        End Try
        con.Close()
        txtfname.Text = ""
        txtlname.Text = ""
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow
            row = Me.DataGridView1.Rows(e.RowIndex)
            txtAcctNo.Text = row.Cells("accountno").Value.ToString
            txtfnme.Text = row.Cells("Firstname").Value.ToString
            txtlnme.Text = row.Cells("Lastname").Value.ToString
            txtaddr.Text = row.Cells("Address").Value.ToString
            txtcontact.Text = row.Cells("Contactno").Value.ToString
            cbGender.Text = row.Cells("Gender").Value.ToString
            txtbday.Text = row.Cells("Birthday").Value.ToString
            txtPincode.Text = row.Cells("pincode").Value.ToString
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        con.Open()
        sql = "Select * from tblinfo"
        Dim ad As New OleDb.OleDbDataAdapter(sql, con)
        Dim data As New DataSet()
        ad.Fill(data, "tblinfo")
        DataGridView1.DataSource = data.Tables("tblinfo").DefaultView
        data.Dispose()
        ad.Dispose()
        con.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub btnedit_Click(sender As Object, e As EventArgs) Handles btnedit.Click
        Dim com As New OleDb.OleDbCommand("delete from tblinfo where Firstname='" & txtfname.Text & "'" & "and Lastname='" & txtlname.Text & "'", con)
        con.Open()
        com.ExecuteNonQuery()
        MsgBox("Record Deleted")
        con.Close()
    End Sub

    Private Sub btnok_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        con.Open()
        sql = "UPDATE tblinfo SET accountno='" & txtAcctNo.Text & "', Firstname='" & txtfnme.Text & "',Lastname='" & txtlnme.Text & "',Contactno='" & txtcontact.Text & "',Gender='" & cbGender.Text & "',pincode= '" & txtPincode.Text & "' where Firstname='" & txtfnme.Text & "' and Lastname='" & txtlnme.Text & "';"
        Dim cmd As New OleDb.OleDbCommand(sql, con)
        cmd.CommandText = sql
        cmd.Connection = con
        cmd.ExecuteNonQuery()
        cmd.Dispose()
        MsgBox("Success")
        MsgBox("YOU CAN UPDATE NEXT TIME AFTER 24 HOURS")
        con.Close()
        DataGridView1.Refresh()
    End Sub

    Private Sub btncancel_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnblock_Click(sender As Object, e As EventArgs) Handles btnblock.Click
     
        con.Open()
        Dim ad As New OleDb.OleDbDataAdapter("select * from tblinfo", con)
        sql = "UPDATE tblinfo SET type= '" & "Block" & "'" & "where Firstname = '" & txtfnme.Text & "'"
        cmd.CommandText = sql
        cmd.Connection = con
        cmd.ExecuteNonQuery()
        cmd.Dispose()
        MsgBox("Success")
        con.Close()
        Button5_Click(sender, e)
    End Sub

    Private Sub btnunblock_Click(sender As Object, e As EventArgs) Handles btnunblock.Click
        con.Open()
        Dim ad As New OleDb.OleDbDataAdapter("select * from tblinfo", con)
        ad.Update(myds, "tblinfo")
        MsgBox("Success")
        con.Close()
        Button5_Click(sender, e)
    End Sub

    
    Private Sub GroupBox2_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles GroupBox2.MouseDoubleClick
        GroupBox2.Enabled = True
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub
End Class