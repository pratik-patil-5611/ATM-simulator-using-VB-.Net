﻿Public Class Receipt
    Dim con As New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\comp6\Documents\atmsys.accdb")
    Dim dt As New DataTable
    Dim sql As String
    Dim cmd As New OleDb.OleDbCommand
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If lblnewbal.Text = "" Then

        Else
            con.Open()
            Dim total As Integer = lblnewbal.Text
            Dim da As New OleDb.OleDbDataAdapter("select * from tblinfo", con)
            sql = "Update tblinfo set balance='" & total & "'" & "where Firstname='" & lblname.Text & "'"
            cmd.CommandText = sql
            cmd.Connection = con
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            con.Close()
        End If
        If MessageBox.Show("Do You want to continue your transaction!!", "Continue", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            Mainmenu.Show()
        Else
            MsgBox("Thank You Come Again")
            Form1.Show()
        End If
        Me.Close()
    End Sub

    Private Sub Receipt_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lbldate.Text = Date.Now

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Mainmenu.Show()
        Me.Hide()
    End Sub

    
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub lbldate_Click(sender As Object, e As EventArgs) Handles lbldate.Click

    End Sub
End Class